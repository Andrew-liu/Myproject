#include "Config.h"

Config::Config()
    :filename_("../config/New_Novel.txt"),
     wcache_("../config/cache.txt"),
     out_("../config/directory.txt")
{}

Config::~Config()
{}


